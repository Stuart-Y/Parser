#include "EndFileAutomaton.h"
