#include "StringAutomaton.h"
